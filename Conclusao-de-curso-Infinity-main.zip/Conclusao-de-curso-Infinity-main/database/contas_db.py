CONTA = [{"login": "adm", "senha": "senha", "tipo": "administrador"},
         {"login": "funcionario", "senha": "senha", "tipo": "funcionario"},
         {"login": "gerente", "senha": "senha", "tipo": "gerente"}]